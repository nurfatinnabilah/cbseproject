/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Payment;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import model.PaymentFacade;

/**
 *
 * @author Acer
 */
@ManagedBean
@SessionScoped
public class paymentController {
    @EJB
    private PaymentFacade paymentFacade;
    private Payment payment=new Payment();

    /**
     * Creates a new instance of paymentController
     */
    public paymentController() {
    }
    
     public String insert(){
        this.paymentFacade.create(payment);
        this.payment = new Payment();
        return "index";
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }
     
     
}
