/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller2;

import entitiesDua.Report;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import modelDua.ReportFacade;

/**
 *
 * @author MrKrab
 */
@ManagedBean
@SessionScoped
public class managedBeanDua implements Serializable {

    @EJB
    private ReportFacade reportFacade;
    private Report report = new Report();

    /**
     * Creates a new instance of managedBeanDua
     */
    public managedBeanDua() {
    }

    public Report getReport() {
        return report;
    }

    public void setReport(Report report) {
        this.report = report;
    }

    //Read Data Into DB
    public List<Report> findAll() {
        return this.reportFacade.findAll();
    }

    //Add Data Into DB
    public String insert() {
        this.reportFacade.create(report);
        this.report = new Report();
        return "index";
    }

    //Delete Data Into DB
    public String delete(Report report) {
        this.reportFacade.remove(report);
        return "index";
    }
    
    //Update Data Into DB
    public String update(Report report) {
        this.report=report;
        return "updateReport";
    }
    
    public String update() {
        this.reportFacade.edit(this.report);
        return "index";
    }

}
