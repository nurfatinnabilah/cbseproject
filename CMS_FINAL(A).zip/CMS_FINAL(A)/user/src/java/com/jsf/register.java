/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Danial
 */
@ManagedBean
@SessionScoped
public class register {

    private String name,email,password,cpassword,id;
    /**
     * Creates a new instance of register
     */
    public register() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCpassword() {
        return cpassword;
    }

    public void setCpassword(String cpassword) {
        this.cpassword = cpassword;
    }
    
    
    public String addUser() throws SQLException{

        Connection conn = null;
        PreparedStatement st = null;
        
        try{    
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/cmsstring", "abc", "123");
            st = conn.prepareStatement("insert into users values (?,?,?,?)");
            st.setString(1,id);
            st.setString(2, name);
            st.setString(3, email);
            st.setString(4, password);
                
            if(password.equals(cpassword)){
                int a = st.executeUpdate();
                    if (a>0) {
                    //execute stmt, update table
                    return "index.xhtml";
                    }
            }
            
            }catch (Exception e){
                return "error2.xhtml";
            }
        return "error2.xhtml";
    }
    
}
