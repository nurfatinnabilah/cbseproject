/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.jsf;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

/**
 *
 * @author Danial
 */
@ManagedBean
@SessionScoped
public class login {

    /**
     * Creates a new instance of users
     */
    public login() {
    }
    
    private String id;
    private String password;

    public String verify() throws SQLException{
        
        Connection conn = null;
        PreparedStatement ps = null;
        
        try{
        conn = DriverManager.getConnection("jdbc:derby://localhost:1527/cmsstring", "abc", "123");
        ps = conn.prepareStatement("Select id, password from Users where id = ? and password = ?");
			ps.setString(1, id);
			ps.setString(2, password);
                        
                        ResultSet rs = ps.executeQuery();
                        
                        if(id.contains("IN")){
                            if (rs.next()) {
                                    //result found, means valid inputs
                                    return "HomeIns.xhtml";
                            }
                        }
                        else
                            if (rs.next()) {
                                    //result found, means valid inputs
                                    return "HomeStud.xhtml";
                            }
        }catch (SQLException ex) {
			return "error.xhtml";
		} finally {
			conn.close();
		}
		return "error.xhtml";
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String logout(){
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        return "index.xhtml";
    }
    
    
}
