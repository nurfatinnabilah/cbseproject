/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.Profile;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import model.ProfileFacade;

/**
 *
 * @author MrKrab
 */
@ManagedBean
@SessionScoped
public class managedBean implements Serializable {

    @EJB
    private ProfileFacade profileFacade;
    private Profile profile = new Profile();

    /**
     * Creates a new instance of managedBean
     */
    public managedBean() {
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }
    
    
    
    public List<Profile> findAll() {
        return this.profileFacade.findAll();
    }
    
    public String insert() {
        this.profileFacade.create(profile);
        this.profile = new Profile();
        return "index" ;
    }

    public String update(Profile profile) {
        this.profile=profile;
        return "updateProfile";
    }
    
    public String update() {
        this.profileFacade.edit(this.profile);
        return "index";
    }
}
