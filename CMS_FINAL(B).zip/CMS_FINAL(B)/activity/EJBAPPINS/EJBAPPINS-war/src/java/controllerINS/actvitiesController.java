/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllerINS;

import entities.Actvities;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import modelINS.ActvitiesFacade;

/**
 *
 * @author User
 */
@ManagedBean
@SessionScoped
public class actvitiesController implements Serializable {
    @EJB
    private ActvitiesFacade actvitiesFacade;
    private Actvities actvities = new Actvities();

    
    /**
     * Creates a new instance of actvitiesController
     */
    public actvitiesController() {
    }

    public Actvities getActvities() {
        return actvities;
    }

    public void setActvities(Actvities actvities) {
        this.actvities = actvities;
    }
    
    public List<Actvities>findAll(){
        return this.actvitiesFacade.findAll();
    }
    public String insert(){
        this.actvitiesFacade.create(actvities);
        this.actvities = new Actvities();
        return "index";
    }
    public String delete(Actvities actvities){
        this.actvitiesFacade.remove(actvities);
        return "index";
    }
    public String update(Actvities actvities){
        this.actvities=actvities;
        return "update";
    }
    public String update(){
        this.actvitiesFacade.edit(actvities);
        return "index";
    }
}
