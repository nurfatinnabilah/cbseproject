/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author User
 */
@Entity
@Table(name = "ACTVITIES")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Actvities.findAll", query = "SELECT a FROM Actvities a"),
    @NamedQuery(name = "Actvities.findByActvityId", query = "SELECT a FROM Actvities a WHERE a.actvityId = :actvityId"),
    @NamedQuery(name = "Actvities.findByActivityName", query = "SELECT a FROM Actvities a WHERE a.activityName = :activityName"),
    @NamedQuery(name = "Actvities.findByDates", query = "SELECT a FROM Actvities a WHERE a.dates = :dates")})
public class Actvities implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "ACTVITY_ID")
    private Integer actvityId;
    @Size(max = 50)
    @Column(name = "ACTIVITY_NAME")
    private String activityName;
    @Lob
    @Size(max = 32700)
    @Column(name = "LOCATION")
    private String location;
    @Lob
    @Size(max = 32700)
    @Column(name = "DESCRIPTION")
    private String description;
    @Column(name = "DATES")
    @Temporal(TemporalType.DATE)
    private Date dates;

    public Actvities() {
    }

    public Actvities(Integer actvityId) {
        this.actvityId = actvityId;
    }

    public Integer getActvityId() {
        return actvityId;
    }

    public void setActvityId(Integer actvityId) {
        this.actvityId = actvityId;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDates() {
        return dates;
    }

    public void setDates(Date dates) {
        this.dates = dates;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (actvityId != null ? actvityId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Actvities)) {
            return false;
        }
        Actvities other = (Actvities) object;
        if ((this.actvityId == null && other.actvityId != null) || (this.actvityId != null && !this.actvityId.equals(other.actvityId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Actvities[ actvityId=" + actvityId + " ]";
    }
    
}
