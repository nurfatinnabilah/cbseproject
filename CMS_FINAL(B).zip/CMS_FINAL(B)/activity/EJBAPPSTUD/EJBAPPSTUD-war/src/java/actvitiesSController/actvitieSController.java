/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package actvitiesSController;

import entities.Actvities;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import modelSTUD.ActvitiesFacade;

/**
 *
 * @author User
 */
@ManagedBean
@SessionScoped
public class actvitieSController implements Serializable {
    @EJB
    private ActvitiesFacade actvitiesFacade;
    

    /**
     * Creates a new instance of actvitieSController
     */
    public actvitieSController() {
    }
    
    public List<Actvities>findAll(){
        return this.actvitiesFacade.findAll();
        
    }
    
}
